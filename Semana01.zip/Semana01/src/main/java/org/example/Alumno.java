package org.example;

public class Alumno {
    //Una linea de comentario
    private int codigo;



    private String nombres;
    private int nota1;
    private int nota2;
    private int nota3;

    public Alumno(int codigo, String nombres, int nota1, int nota2, int nota3) {
        this.codigo = codigo;
        this.nombres = nombres;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
    }

    //Constructor sin parametros
    public Alumno() {

    }
    //Obtener el nombre
    public String getNombres() {
        return nombres;
    }
    //Fijar el nombre
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }
    //Metodo para escribir en consola
    public void mensaje() {
        System.out.println("Hola soy de la clae alumno");
    }

    public void mensajeParametro(String msg) {

        System.out.println(msg);
    }

    public void mensajeAtributo() {

        System.out.println(this.nombres);
    }

    //calcular promedio
    public double promedio () {
        double resultado=0;
        resultado = (this.nota1 + this.nota2 + this.nota3)/3;
        return resultado;
    }


}

package org.example;

import org.librerias.Funciones;
//import org.librerias.*;

public class Main {
    public static void main(String[] args) {
        //System.out.println("Clase de semana 1 java");
        Alumno objAlumno01 = new Alumno(1,"Jymmy",12,10,14);
        //Llamar al metodo de la clase alumno
        objAlumno01.mensaje();

        objAlumno01.mensajeParametro("Hola soy Jymmy Dextre");

        //Sale nombre jymmy
        objAlumno01.mensajeAtributo();
        objAlumno01.setNombres("Jaime Coronado");
        objAlumno01.mensajeAtributo();

        Alumno objAlumno02 = new Alumno();
        objAlumno02.mensajeAtributo();

        //llama al metodo promedio
        double promedio=objAlumno01.promedio();
        objAlumno01.mensajeParametro(String.valueOf(promedio));

        //Llamar a la clase Funciones
        Funciones objFunciones = new Funciones("Saludar");
        objFunciones.saludar();

    }
}
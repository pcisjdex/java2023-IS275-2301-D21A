package org.librerias;

public class Funciones {
    private String mensaje;
    public Funciones(String mensaje) {
        this.mensaje = mensaje;
    }

    public void saludar() {
        System.out.print(this.mensaje);
    }



}
